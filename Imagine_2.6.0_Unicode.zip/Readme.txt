Imagine - Image & Animation Viewer for Windows, Freeware (Donationware)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Copyright (c) 2003-2026  Sejin Chun
Website: http://www.nyam.pe.kr

[Features]
* View and save image/animation files with very fast speed
* Support for numerous image/animation file formats:
  - ANI, ANM, AVIF, BMP, BPG, CDR, CLIP, CLP, CUR, DCM, DCX, DDS, EMF, EXR,
    FLC, FLI, FLIF, GIF, HDP, HDR, HEIF, ICL, ICNS, ICO, JBG, JNG, JP2, JPC,
    JPG, JXL, LBM, MAC, MBM, MNG, PAM, PBM, PCD, PCX, PDN, PFM, PGM, PIC, PNG,
    PPM, PSD, PSP, QOI, RAS, RLA, RLE, SGI, SPR, SVG, TGA, TGS, TIF, WBMP,
    WEBP, WMF, WPG, XBM, XCF, XPM
* Support for digital camera RAW image file formats:
  - 3FR, ARW, BAY, BMQ, CAP, CINE, CR2, CR3, CRW, CS1, DC2, DCR, DNG, ERF, FFF,
    GPR, IA, IIQ, K25, KC2, KDC, MDC, MEF, MOS, MRW, NEF, NRW, ORF, ORI, PEF,
    PTX, PXN, QTK, RAF, RAW, RDC, RW1, RW2, RWL, SR2, SRF, SRW, STI, X3F
* Support for numerous archive file formats:
  - ZIP, RAR, 7Z, ALZ, HV3, CBZ, CBR, CB7
* Support for high dynamic range image file formats:
  - HDR, EXR, SXR, MXR
* Extract single/all frames from animation files
* Show detailed information of image/animation files
* Show Exif/XMP/IPTC/DICOM/Comment information
* Show or hide transparency
* 64-bit version available
* Unicode version available
* Multilingual support
* Thumbnail browser
* Basic paint
* Color corrections
* Color management (ICC Profile)
* Batch conversion
* Slide show
* Batch rename
* Capture screen
* Tiled view
* Create animations
* Create multiple page images
* Create panorama images
* Manipulate and edit images:
  - Flip vertical and horizontal
  - Rotate left, right and free
  - Grayscale
  - Negative
  - Change color depth (1, 4, 8, 16, 24 and 32 bit)
  - Swap colors
  - Resize per pixel, percentage or standard dimensions.
  - Several resample filters available.
  - Effect filters, including a handy Preview browser
  - Import, export and edit palettes
  - Set and remove transparency
* Customizable shortcuts for Keyboard and Mouse
* Command line parameter support
* Shell extension support
* Add-on plugin support
* Total Commander Lister, Packer and Content plugin
* No write unnecessary registry (ini-based configuration)
* Native support for x86, x64, and arm64 architectures
* Fully optimized binaries (tiny, pure, fast, neat)

[System requirements]
* CPU: Pentium compatible(x86, x64), ARM64(AArch64)
* RAM: 32MB or higher
* OS: Microsoft Windows 95/98/ME/NT 4.0/2000/XP/2003/Vista/7/8/10/11
* Display: 256 color or higher
