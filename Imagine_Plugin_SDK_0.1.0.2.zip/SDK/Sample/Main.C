#define STRICT
#define WIN32_LEAN_AND_MEAN

#include <string.h>
#include <windows.h>
#include "ImagPlug.H"
#include "IPS.H"

static BOOL IMAGINEAPI ImaginePluginRegister(LPCIMAGINEPLUGININTERFACE iface);

static const IMAGINEPLUGININFO infos=
{
	ImaginePluginRegister,
	TEXT(IMAGINEPLUGIN_VERSION),
	TEXT("Imagine Plugin Sample File Plugin"),
};

BOOL CALLBACK DllMain(HINSTANCE hInstance,DWORD dwReason,LPVOID lpvReserved)
{
	return TRUE;
}

BOOL IMAGINEAPI ImaginePluginGetInfo(LPIMAGINEPLUGININFO info)
{
	memcpy(info,&infos,sizeof(*info));

	return TRUE;
}

static BOOL IMAGINEAPI ImaginePluginRegister(LPCIMAGINEPLUGININTERFACE iface)
{
	LPCIMAGINEFILEINFO ifi;

	ifi=IPSGetFileInfo();

	return iface->lpVtbl->RegisterFileType(ifi);
}
