#define STRICT
#define WIN32_LEAN_AND_MEAN

#include <string.h>
#include <windows.h>
#include "ImagPlug.H"
#include "IPS.H"

static BOOL IMAGINEAPI ImaginePluginRegister(LPVOID dfi);

static const IMAGINEPLUGININFO infos=
{
	IMAGINEPLUGINTYPE_FILETYPE,
	ImaginePluginRegister,
	TEXT(IMAGINEPLUGIN_VERSION),
	TEXT("Imagine Plugin Sample File Plugin"),
};

BOOL CALLBACK DllMain(HINSTANCE hInstance,DWORD dwReason,LPVOID lpvReserved)
{
	return TRUE;
}

BOOL IMAGINEAPI ImaginePluginGetInfo(LPIMAGINEPLUGININFO info)
{
	memcpy(info,&infos,sizeof(*info));

	return TRUE;
}

static BOOL IMAGINEAPI ImaginePluginRegister(LPVOID dfi)
{
	return IPSRegisterFileType(dfi);
}
