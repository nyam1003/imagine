#include "Main.H"

#define VERSION_NUMBER1 1
#define VERSION_NUMBER2 0
#define VERSION_NUMBER3 0
#define VERSION_NUMBER4 0
#define VERSION_NUMBER (VERSION_NUMBER1<<24)|(VERSION_NUMBER2<<16)|(VERSION_NUMBER3<<8)|(VERSION_NUMBER4<<0)

static BOOL IMAGINEAPI registerProcA(const IMAGINEPLUGININTERFACE *iface)
{
	return (BOOL)iface->lpVtbl->RegisterFileType(IPSGetFileInfoA());
}

static BOOL IMAGINEAPI registerProcW(const IMAGINEPLUGININTERFACE *iface)
{
	return (BOOL)iface->lpVtbl->RegisterFileType(IPSGetFileInfoW());
}

// Plugin info (ANSI)
static const IMAGINEPLUGININFOA pluginInfoA=
{
	sizeof(pluginInfoA),
	registerProcA,
	VERSION_NUMBER,
	"Imagine Plugin Sample Format Plugin",
	IMAGINEPLUGININTERFACE_VERSION,
};

// Plugin info (Unicode)
static const IMAGINEPLUGININFOW pluginInfoW=
{
	sizeof(pluginInfoW),
	registerProcW,
	VERSION_NUMBER,
	L"Imagine Plugin Sample Format Plugin",
	IMAGINEPLUGININTERFACE_VERSION,
};

BOOL CALLBACK DllMain(HINSTANCE hInstance,DWORD dwReason,LPVOID lpvReserved)
{
	return TRUE;
}

BOOL IMAGINEAPI ImaginePluginGetInfoA(IMAGINEPLUGININFOA *dest)
{
	BOOL result=TRUE;

	*dest=pluginInfoA;

	return result;
}

BOOL IMAGINEAPI ImaginePluginGetInfoW(IMAGINEPLUGININFOW *dest)
{
	BOOL result=TRUE;

	*dest=pluginInfoW;

	return result;
}
