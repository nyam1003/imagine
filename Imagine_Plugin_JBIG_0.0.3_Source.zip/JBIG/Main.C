#include "Main.H"

static BOOL IMAGINEAPI registerProc(const IMAGINEPLUGININTERFACE *iface)
{
	BOOL result=TRUE;
	const IMAGINEFILEINFOITEM *fileInfoItem=(const IMAGINEFILEINFOITEM *)JBIGGetFileInfo();
	if (fileInfoItem!=NULL)
	{
		IMAGINEFILEINFOITEM _fileInfoItem=*fileInfoItem;

		if (iface->lpVtbl->IsUnicode())
		{
			_fileInfoItem.fileType=(LPCTSTR)UNICODE_TEXT(FILETYPE_JBIG);
			_fileInfoItem.extension=(LPCTSTR)UNICODE_TEXT(EXTENSION_JBIG);
		}

		iface->lpVtbl->RegisterFileType(&_fileInfoItem);
	}

	return result;
}

static const IMAGINEPLUGININFOA pluginInfoA=
{
	sizeof(pluginInfoA),
	registerProc,
	VERSION_NUMBER,
	INSTANCE_NAME,
	IMAGINEPLUGININTERFACE_VERSION,
};

static const IMAGINEPLUGININFOW pluginInfoW=
{
	sizeof(pluginInfoW),
	registerProc,
	VERSION_NUMBER,
	UNICODE_TEXT(INSTANCE_NAME),
	IMAGINEPLUGININTERFACE_VERSION,
};

BOOL CALLBACK DllMain(HINSTANCE hInstance,DWORD dwReason,LPVOID lpvReserved)
{
	BOOL result=TRUE;

	return result;
}

BOOL IMAGINEAPI ImaginePluginGetInfoA(IMAGINEPLUGININFOA *dest)
{
	BOOL result=TRUE;

	*dest=pluginInfoA;

	return result;
}

BOOL IMAGINEAPI ImaginePluginGetInfoW(IMAGINEPLUGININFOW *dest)
{
	BOOL result=TRUE;

	*dest=pluginInfoW;

	return result;
}
