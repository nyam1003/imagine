#include "Main.H"

static void importPalette(PALETTEENTRY palettes[],const IPSPALETTEENTRY entries[],int entryCount)
{
	PALETTEENTRY *palette;
	const IPSPALETTEENTRY *entry;
	int i;

	for (i=0;i<entryCount;i++)
	{
		palette=&palettes[i];
		entry=&entries[i];

		palette->peRed=entry->red;
		palette->peGreen=entry->green;
		palette->peBlue=entry->blue;
		palette->peFlags=0;
	}

	return;
}

static void exportPalette(const PALETTEENTRY palettes[],IPSPALETTEENTRY entries[],int entryCount)
{
	const PALETTEENTRY *palette;
	IPSPALETTEENTRY *entry;
	int i;

	for (i=0;i<entryCount;i++)
	{
		palette=&palettes[i];
		entry=&entries[i];

		entry->red=palette->peRed;
		entry->green=palette->peGreen;
		entry->blue=palette->peBlue;
		entry->reserved=0;
	}

	return;
}

static BOOL IMAGINEAPI checkFile(LPIMAGINEPLUGINFILEINFOTABLE fileInfoTable,LPIMAGINELOADPARAM loadParam,int flags)
{
	BOOL isValid=FALSE;
	LPIPSHEADER header;

	header=(LPIPSHEADER)loadParam->buffer;

	if (header->signature==IPS_SIGNATURE)
		isValid=TRUE;

	return isValid;
}

static LPIMAGINEBITMAP IMAGINEAPI loadFile(LPIMAGINEPLUGINFILEINFOTABLE fileInfoTable,LPIMAGINELOADPARAM loadParam,int flags)
{
	LPIMAGINEBITMAP bitmap=NULL;
	LPCIMAGINEPLUGININTERFACE iface;
	LPIPSHEADER header;
	LONG width,height;
	LONG bitCount;
	PALETTEENTRY palette[256];
	LPIPSPALETTEENTRY entry;
	LPBYTE buffer;
	LPBYTE scanline;
	LONG pureWidthBytes;
	IMAGINECALLBACKPARAM callback;
	int y;

	iface=fileInfoTable->iface;
	if (iface!=NULL)
	{
		header=(LPIPSHEADER)loadParam->buffer;

		width=(LONG)header->width;
		height=(LONG)header->height;
		bitCount=(LONG)header->bitCount;

		bitmap=iface->lpVtbl->Create(width,height,bitCount,flags);
		if (bitmap!=NULL)
		{
			if (!(flags&IMAGINELOADPARAM_GETINFO))
			{
				buffer=(LPBYTE)(header+1);

				if (bitCount<=8)
				{
					entry=(LPIPSPALETTEENTRY)buffer;
					importPalette(palette,entry,1<<bitCount);
					iface->lpVtbl->SetPalette(bitmap,palette);
					buffer=(LPBYTE)(entry+(1<<bitCount));
				}

				pureWidthBytes=(width*bitCount)/8;

				callback.dib=bitmap;
				callback.param=loadParam->callback.param;
				callback.current=0;
				callback.overall=height-1;

				for (y=0;y<height;y++)
				{
					scanline=iface->lpVtbl->GetLineBits(bitmap,y);

					memcpy(scanline,buffer,pureWidthBytes);

					if (flags&IMAGINELOADPARAM_CALLBACK)
					{
						if (!loadParam->callback.proc(&callback))
						{
							loadParam->errorCode=IMAGINEERROR_ABORTED;
							break;
						}
					}

					buffer+=pureWidthBytes;
					callback.current++;
				}
			}
		}
		else
		{
			loadParam->errorCode=IMAGINEERROR_OUTOFMEMORY;
		}
	}

	return bitmap;
}

static BOOL IMAGINEAPI saveFile(LPIMAGINEPLUGINFILEINFOTABLE fileInfoTable,LPIMAGINEBITMAP bitmap,LPIMAGINESAVEPARAM saveParam,int flags)
{
	BOOL result=FALSE;
	LPCIMAGINEPLUGININTERFACE iface;
	IPSHEADER header;
	LPIMAGINESMARTBUFFER sb;
	LONG width,height;
	LONG bitCount;
	IMAGINECALLBACKPARAM callback;
	LONG pureWidthBytes;
	LPBYTE scanline;
	PALETTEENTRY palette[256];
	IPSPALETTEENTRY entry[256];
	int length;
	int y;

	iface=fileInfoTable->iface;
	if (iface!=NULL)
	{
		bitCount=iface->lpVtbl->GetBitCount(bitmap);
		switch (bitCount)
		{
		case 8:
		case 24:
			// Assume that only 8bit and 24bit colors are supported.
			break;

		default:
			saveParam->errorCode=IMAGINEERROR_COLORNOTSUPPORTED;
			break;
		}

		if (saveParam->errorCode!=IMAGINEERROR_COLORNOTSUPPORTED)
		{
			if (!(flags&IMAGINESAVEPARAM_TEST)) // The rest can be saved with no problems.
			{
				length=iface->lpVtbl->GetLength(bitmap);
				if (length>0)
				{
					// First argument: The size of initial allocation
					// Second argument: The size of allcation unit (When the initial allocated memory is not enough)
					// They can be any values, but they affect to performance. (Reallocation)
					sb=iface->lpVtbl->sbAlloc(length,32768);
					if (sb!=NULL)
					{
						saveParam->sb=sb;

						width=iface->lpVtbl->GetWidth(bitmap);
						height=iface->lpVtbl->GetHeight(bitmap);

						header.signature=IPS_SIGNATURE;
						header.width=(DWORD)width;
						header.height=(DWORD)height;
						header.bitCount=(DWORD)bitCount;

						if (iface->lpVtbl->sbWrite(sb,sb->current,&header,sizeof(header))!=NULL)
						{
							if (bitCount<=8)
							{
								iface->lpVtbl->GetPalette(bitmap,palette);
								exportPalette(palette,entry,1<<bitCount);

								if (iface->lpVtbl->sbWrite(sb,sb->current,entry,sizeof(*entry)*(1<<bitCount))==NULL)
									saveParam->errorCode=IMAGINEERROR_WRITEERROR;
							}

							if (saveParam->errorCode==IMAGINEERROR_NOERROR)
							{
								callback.dib=bitmap;
								callback.param=saveParam->callback.param;
								callback.current=0;
								callback.overall=height-1;

								pureWidthBytes=iface->lpVtbl->GetPureWidthBytes(bitmap);
								if (pureWidthBytes>0)
								{
									for (y=0;y<height;y++)
									{
										scanline=iface->lpVtbl->GetLineBits(bitmap,y);

										if (iface->lpVtbl->sbWrite(sb,sb->current,scanline,pureWidthBytes)==NULL)
										{
											saveParam->errorCode=IMAGINEERROR_WRITEERROR;
											break;
										}

										if (flags&IMAGINESAVEPARAM_CALLBACK)
										{
											if (!saveParam->callback.proc(&callback))
											{
												saveParam->errorCode=IMAGINEERROR_ABORTED;
												break;
											}
										}

										callback.current++;
									}
								}
							}
						}
						else
						{
							saveParam->errorCode=IMAGINEERROR_WRITEERROR;
						}
					}
					else
					{
						saveParam->errorCode=IMAGINEERROR_OUTOFMEMORY;
					}
				}
			}

			if (saveParam->errorCode==IMAGINEERROR_NOERROR)
				result=TRUE;
		}
	}

	return result;
}

// file information (ANSI version)
static const IMAGINEFILEINFOITEM ifiA=
{
	checkFile, // Check procedure
	loadFile, // Load buffer procedure
	saveFile, // Save buffer procedure
	(LPVOID)("Imagine Plugin Sample"), // Image file description
	(LPVOID)("IPS\0IPSF\0"), // Image file extension
};

// file information (UNICODE version)
static const IMAGINEFILEINFOITEM ifiW=
{
	checkFile, // Check procedure
	loadFile, // Load buffer procedure
	saveFile, // Save buffer procedure
	(LPVOID)(L"Imagine Plugin Sample"), // Image file description
	(LPVOID)(L"IPS\0IPSF\0"), // Image file extension
};

LPCIMAGINEFILEINFOITEM IMAGINEAPI IPSGetFileInfoA(void)
{
	return &ifiA;
}

LPCIMAGINEFILEINFOITEM IMAGINEAPI IPSGetFileInfoW(void)
{
	return &ifiW;
}
