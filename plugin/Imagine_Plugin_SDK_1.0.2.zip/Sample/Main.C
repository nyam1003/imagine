#include "Main.H"

static BOOL IMAGINEAPI ImaginePluginRegisterA(LPCIMAGINEPLUGININTERFACE iface)
{
	BOOL result=FALSE;
	LPCIMAGINEFILEINFOITEM fileInfoItem;

	fileInfoItem=IPSGetFileInfoA();
	if (fileInfoItem!=NULL)
	{
		if (iface->lpVtbl->RegisterFileType(fileInfoItem)!=NULL)
			result=TRUE;
	}

	return result;
}

static BOOL IMAGINEAPI ImaginePluginRegisterW(LPCIMAGINEPLUGININTERFACE iface)
{
	BOOL result=FALSE;
	LPCIMAGINEFILEINFOITEM fileInfoItem;

	fileInfoItem=IPSGetFileInfoW();
	if (fileInfoItem!=NULL)
	{
		if (iface->lpVtbl->RegisterFileType(fileInfoItem)!=NULL)
			result=TRUE;
	}

	return result;
}

static const IMAGINEPLUGININFO pluginInfoA=
{
	sizeof(pluginInfoA),
	ImaginePluginRegisterA,
	IMAGINEPLUGININTERFACE_VERSION,
	(LPVOID)("Imagine Plugin Sample File Plugin"),
};

static const IMAGINEPLUGININFO pluginInfoW=
{
	sizeof(pluginInfoW),
	ImaginePluginRegisterW,
	IMAGINEPLUGININTERFACE_VERSION,
	(LPVOID)L"Imagine Plugin Sample File Plugin",
};

BOOL CALLBACK DllMain(HINSTANCE hInstance,DWORD dwReason,LPVOID lpvReserved)
{
	BOOL result=TRUE;

	return result;
}

BOOL IMAGINEAPI ImaginePluginGetInfoA(LPIMAGINEPLUGININFO dest)
{
	BOOL result=FALSE;

	if (dest!=NULL)
	{
		memcpy(dest,&pluginInfoA,sizeof(*dest));
		result=TRUE;
	}

	return result;
}

BOOL IMAGINEAPI ImaginePluginGetInfoW(LPIMAGINEPLUGININFO dest)
{
	BOOL result=FALSE;

	if (dest!=NULL)
	{
		memcpy(dest,&pluginInfoW,sizeof(*dest));
		result=TRUE;
	}

	return result;
}
