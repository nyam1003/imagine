#include "Main.H"

typedef struct DIALOG
{
	const IMAGINEPLUGININTERFACE *iface;
	HINSTANCE hInstance;
	HWND hDlg;
	HICON hIcon;
	HFONT hFont;
} DIALOG;

#define GetDialog(hDlg) ((DIALOG *)GetWindowLongPtr(hDlg,GWLP_USERDATA))
#define SetDialog(hDlg,dialog) do {SetWindowLongPtr(hDlg,GWLP_USERDATA,(LONG_PTR)(dialog));(dialog)->hDlg=hDlg;} while (0)

#define ID_MENUITEM_HELP_ABOUT 40025

static BOOL onInitDialog(HWND hDlg,DIALOG *dialog)
{
	BOOL result=TRUE;

	if (dialog!=NULL)
	{
		SetDialog(hDlg,dialog);

		dialog->hFont=dialog->iface->lpVtbl->CreateUIFont(dialog->hDlg);
		dialog->iface->lpVtbl->ProcessDialog(dialog->hDlg,ID_MENUITEM_HELP_ABOUT,0,dialog->hFont);

		{
			LPCTSTR text=
			(
				dialog->iface->lpVtbl->IsUnicode()
				? (LPCTSTR)UNICODE_TEXT(INSTANCE_DESCRIPTION)UNICODE_TEXT("\r\n\r\n")UNICODE_TEXT(INSTANCE_COPYRIGHT)
				: INSTANCE_DESCRIPTION"\r\n\r\n"INSTANCE_COPYRIGHT
			);
			// LPCTSTR caption=INSTANCE_FILE_NAME;
			FARPROC setDlgItemText=dialog->iface->lpVtbl->IsUnicode()?(FARPROC)SetDlgItemTextW:(FARPROC)SetDlgItemTextA;

			setDlgItemText(dialog->hDlg,IDC_EDIT_INFO,text);
		}
	}

	return result;
}

static int onCommand(HWND hDlg,UINT id,int notifyCode,HWND hwndControl)
{
	int result=-1;
	DIALOG *dialog=GetDialog(hDlg);
	if (dialog!=NULL)
	{
		switch (id)
		{
		case IDOK:
		case IDCANCEL:
			EndDialog(dialog->hDlg,((id==IDOK)?(0):(-1)));
			result=0;
			break;

		case IDC_BUTTON_CREDITS:
			{
				LPCTSTR type=dialog->iface->lpVtbl->IsUnicode()?(LPCTSTR)UNICODE_TEXT("PACKED"):(LPCTSTR)"PACKED";
				const IMAGINECREDITSDIALOGPARAM param={{dialog->hInstance,MAKEINTRESOURCE(IDR_ARCHIVE_CREDITS),type}};

				dialog->iface->lpVtbl->CreditsDialog(hDlg,&param);
			}
			result=0;
			break;
		}
	}

	return result;
}

static int onDestroy(HWND hDlg)
{
	int result=0;
	DIALOG *dialog=GetDialog(hDlg);
	if (dialog!=NULL)
	{
		if (dialog->hIcon!=NULL)
		{
			DestroyIcon(dialog->hIcon);
			dialog->hIcon=NULL;
		}

		if (dialog->hFont!=NULL)
		{
			DeleteObject(dialog->hFont);
			dialog->hFont=NULL;
		}
	}

	return result;
}

static INT_PTR CALLBACK wndProc(HWND hDlg,UINT iMsg,WPARAM wParam,LPARAM lParam)
{
	DEFINE_DLGRESULT();

	switch (iMsg)
	{
	case WM_INITDIALOG:
		SET_RESULT(iMsg,onInitDialog(hDlg,(DIALOG *)lParam));
		break;

	case WM_COMMAND:
		if (onCommand(hDlg,(UINT)LOWORD(wParam),(int)HIWORD(wParam),(HWND)lParam)==0)
			SET_RESULT(iMsg,0);

		break;

	case WM_DESTROY:
		SET_RESULT(iMsg,onDestroy(hDlg));
		break;
	}

	RETURN_RESULT(hDlg);
}

BOOL InfoDialog(const IMAGINEPLUGININTERFACE *iface,HINSTANCE hInstance,HWND parent)
{
	BOOL result=TRUE;
	DIALOG dialog={iface,hInstance};

	DialogBoxParam(hInstance,MAKEINTRESOURCE(IDD_DIALOG_INFO),parent,wndProc,(LPARAM)&dialog);

	return result;
}
