#define STRICT
#define WIN32_LEAN_AND_MEAN

#include <string.h>
#include <windows.h>
#include "ImagPlug.H"
#include "IPS.H"

static BOOL IMAGINEAPI ImaginePluginRegisterA(LPCIMAGINEPLUGININTERFACE iface);
static BOOL IMAGINEAPI ImaginePluginRegisterW(LPCIMAGINEPLUGININTERFACE iface);

static const IMAGINEPLUGININFO infoA=
{
	sizeof(infoA),
	ImaginePluginRegisterA,
	(LPVOID)(IMAGINEPLUGININTERFACE_VERSION),
	(LPVOID)("Imagine Plugin Sample File Plugin"),
};

static const IMAGINEPLUGININFO infoW=
{
	sizeof(infoW),
	ImaginePluginRegisterW,
	TEXT(IMAGINEPLUGININTERFACE_VERSION),
	TEXT("Imagine Plugin Sample File Plugin"),
};

BOOL CALLBACK DllMain(HINSTANCE hInstance,DWORD dwReason,LPVOID lpvReserved)
{
	return TRUE;
}

BOOL IMAGINEAPI ImaginePluginGetInfoA(LPIMAGINEPLUGININFO dest)
{
	memcpy(dest,&infoA,sizeof(*dest));

	return TRUE;
}

BOOL IMAGINEAPI ImaginePluginGetInfoW(LPIMAGINEPLUGININFO dest)
{
	memcpy(dest,&infoW,sizeof(*dest));

	return TRUE;
}

static BOOL IMAGINEAPI ImaginePluginRegisterA(LPCIMAGINEPLUGININTERFACE iface)
{
	LPCIMAGINEFILEINFOITEM ifii;

	ifii=IPSGetFileInfoA();

	if (iface->lpVtbl->RegisterFileType(ifii)==NULL)
		return FALSE;

	return TRUE;
}

static BOOL IMAGINEAPI ImaginePluginRegisterW(LPCIMAGINEPLUGININTERFACE iface)
{
	LPCIMAGINEFILEINFOITEM ifii;

	ifii=IPSGetFileInfoW();

	if (iface->lpVtbl->RegisterFileType(ifii)==NULL)
		return FALSE;

	return TRUE;
}
