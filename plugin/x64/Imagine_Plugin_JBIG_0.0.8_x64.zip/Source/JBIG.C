#include <stdio.h>
#include <setjmp.h>
#include "Main.H"

#if (!defined(DIBFILETYPE_JBIG))
	#define DIBFILETYPE_JBIG "JBIG Bi-level Image"
#endif

#if (!defined(DIBEXTENSION_JBIG))
	#define DIBEXTENSION_JBIG "JBG\0JBIG\0"
#endif

typedef struct LOAD_USER_DATA
{
	IMAGINEPLUGINFILEINFOTABLE *fileInfoTable;
	IMAGINELOADPARAM *loadParam;
	int flags;
	struct jbg_dec_state jbig_state;
	jmp_buf jmpb;
	IMAGINECALLBACKPARAM callbackParam;
} LOAD_USER_DATA;

typedef struct SAVE_USER_DATA
{
	IMAGINEPLUGINFILEINFOTABLE *fileInfoTable;
	IMAGINESAVEPARAM *saveParam;
	int flags;
	struct jbg_enc_state jbig_state;
	jmp_buf jmpb;
	IMAGINECALLBACKPARAM callbackParam;
} SAVE_USER_DATA;

static void invertScanline(BYTE *buffer,int bufferLength)
{
	int i;

	for (i=bufferLength/sizeof(DWORD);i>0;i--,buffer+=sizeof(DWORD))
		*((DWORD *)buffer)^=0xFFFFFFFF;

	for (i=bufferLength%sizeof(DWORD);i>0;i--,buffer+=sizeof(BYTE))
		*((BYTE *)buffer)^=0xFF;
}

static void dataOutProc(unsigned char *start,size_t len,SAVE_USER_DATA *userData)
{
	IMAGINEPLUGINFILEINFOTABLE *fileInfoTable=userData->fileInfoTable;
	IMAGINESAVEPARAM *saveParam=userData->saveParam;
	const int flags=userData->flags;
	IMAGINECALLBACKPARAM *callbackParam=&userData->callbackParam;

	if (fileInfoTable->iface->lpVtbl->sbWrite(saveParam->sb,saveParam->sb->current,start,len))
	{
		if (0)
		{
			FILE *fp=fopen("dataOutProc.txt","a+");

			if (fp)
			{
//				fprintf(fp,"len: %d, d: %d, xd: %u, yd: %u, yd1: %d, planes: %d, dl: %d, dh: %d, l0: %u, stripes: %u\n",len,userData->jbig_state.d,userData->jbig_state.xd,userData->jbig_state.yd,userData->jbig_state.yd1,userData->jbig_state.planes,userData->jbig_state.dl,userData->jbig_state.dh,userData->jbig_state.l0,userData->jbig_state.stripes);
				fprintf(fp,"order: %d, mx: %u, my: %u, s->c: %u, s->a: %u, s->sc: %d, s->ct: %d, s->buffer: %d\n",userData->jbig_state.order,userData->jbig_state.mx,userData->jbig_state.my,userData->jbig_state.s->c,userData->jbig_state.s->a,userData->jbig_state.s->sc,userData->jbig_state.s->ct,userData->jbig_state.s->buffer);
				fclose(fp);
			}
		}

		if
		(
			(flags&IMAGINESAVEPARAM_CALLBACK)
			&&(!saveParam->callback.proc(callbackParam))
		)
		{
			saveParam->errorCode=IMAGINEERROR_ABORTED;
			longjmp(userData->jmpb,1);
		}

//		Sleep(1000);
	}
	else
	{
		saveParam->errorCode=IMAGINEERROR_WRITEERROR;
	}
}

static BOOL IMAGINEAPI checkFile(IMAGINEPLUGINFILEINFOTABLE *fileInfoTable,IMAGINELOADPARAM *loadParam,int flags)
{
	return (flags&IMAGINELOADPARAM_DETECTEXTENSION);
}

static LPIMAGINEBITMAP IMAGINEAPI loadFile(IMAGINEPLUGINFILEINFOTABLE *fileInfoTable,IMAGINELOADPARAM *loadParam,int flags)
{
	LPIMAGINEBITMAP dib=NULL;
	LOAD_USER_DATA userData=
	{
		fileInfoTable,
		loadParam,
		flags,
	};

	__try
	{
		if (!setjmp(userData.jmpb))
		{
			const size_t numMaxSliceBytes=max(min(loadParam->length/100,1024*1024),1024);
			size_t totalReadBytes=0;
			LONG width=0;
			LONG height=0;
			LONG numPlanes=0;
			size_t bufferLength;

			if (0)
			{
				char buffer[128];
				char *pBuffer=buffer;

				pBuffer+=wsprintfA(pBuffer,"numMaxSliceBytes: %u\n",numMaxSliceBytes);
				MessageBoxA(NULL,buffer,NULL,MB_OK);
			}

			jbg_dec_init(&userData.jbig_state);

			userData.callbackParam.dib=NULL;
			userData.callbackParam.param=loadParam->callback.param;
			userData.callbackParam.overall=100;

			while
			(
				(!loadParam->errorCode)
				&&
				(
					(!(flags&IMAGINELOADPARAM_GETINFO))
					||
					((!width)||(!height)||(!numPlanes))
				)
				&&(totalReadBytes<loadParam->length)
				&&(bufferLength=min(numMaxSliceBytes,loadParam->length-totalReadBytes))
			)
			{
				size_t readBytes=0;

				while
				(
					(!loadParam->errorCode)
					&&(readBytes<bufferLength)
				)
				{
					size_t cnt=0;
					const int status=jbg_dec_in(&userData.jbig_state,(unsigned char *)loadParam->buffer+totalReadBytes,bufferLength-readBytes,&cnt);

					if ((status!=JBG_EAGAIN)&&(status!=JBG_EOK))
						loadParam->errorCode=IMAGINEERROR_INVALIDDATA;

					readBytes+=cnt;
				}

				totalReadBytes+=readBytes;
				userData.callbackParam.current=MulDiv(totalReadBytes,100,loadParam->length);

				if
				(
					(flags&IMAGINELOADPARAM_CALLBACK)
					&&(loadParam->callback.proc)
					&&(!loadParam->callback.proc(&userData.callbackParam))
				)
				{
					//~ MessageBox(NULL,"ABORTED!",NULL,MB_OK);
					loadParam->errorCode=IMAGINEERROR_ABORTED;
					longjmp(userData.jmpb,1);
				}

				width=jbg_dec_getwidth(&userData.jbig_state);
				height=jbg_dec_getheight(&userData.jbig_state);
				numPlanes=jbg_dec_getplanes(&userData.jbig_state);

				//~ Sleep(200);
			}

			if
			(
				(!loadParam->errorCode)
				&&((width)&&(height)&&(numPlanes))
			)
			{
				const LONG bitCount=numPlanes;

				dib=fileInfoTable->iface->lpVtbl->Create(width,height,bitCount,flags);
				if (dib)
				{
					fileInfoTable->iface->lpVtbl->SetCompression(dib,IMAGINECOMPRESSION_JBIG);

					if (!(flags&IMAGINELOADPARAM_GETINFO))
					{
						const LONG bytesPerPlaneScanline=(width+7)/8;
						const LONG widthBytes=fileInfoTable->iface->lpVtbl->GetWidthBytes(dib);
						const LONG pureWidthBytes=fileInfoTable->iface->lpVtbl->GetPureWidthBytes(dib);
						PALETTEENTRY palette[256];
						int planeIndex;

						if (fileInfoTable->iface->lpVtbl->UtilCreateGrayscalePalette(palette,1<<bitCount))
							fileInfoTable->iface->lpVtbl->SetPalette(dib,palette);

						for (planeIndex=0;planeIndex<numPlanes;planeIndex++)
						{
							const unsigned char *plane=jbg_dec_getimage(&userData.jbig_state,planeIndex);
							LONG y;

							for (y=0;y<height;y++)
							{
								const unsigned char *scanline=plane+(y*bytesPerPlaneScanline);
								BYTE *line=fileInfoTable->iface->lpVtbl->GetLineBits(dib,y);

								if (numPlanes<=1) // 1-bit B/W
								{
									memcpy(line,scanline,bytesPerPlaneScanline);
									invertScanline(line,bytesPerPlaneScanline);
								}
								else // 8-bit grayscale
								{
									LONG x;

									if (!planeIndex)
										memset(line,0,pureWidthBytes);

									for (x=0;x<width;x++)
									{
										const BYTE *pScanline=scanline+(x/8);
										const BYTE scanlineData=(*pScanline>>(7-x%8))&1;
										BYTE *pLine=line+((x*numPlanes)/8);
										const BYTE lineData=*pLine;

										*pLine=(lineData<<1)|(scanlineData^(1&lineData));
									}
								}
							}
						}
					}
				}
				else
				{
					loadParam->errorCode=IMAGINEERROR_OUTOFMEMORY;
				}
			}
		}
	}
	__except (EXCEPTION_EXECUTE_HANDLER)
	{
		loadParam->errorCode=IMAGINEERROR_INVALIDDATA;
	}

	if (userData.jbig_state.s)
		jbg_dec_free(&userData.jbig_state);

	return dib;
}

static void freePlanes(IMAGINEPLUGINFILEINFOTABLE *fileInfoTable,int numPlanes,BYTE *planes[])
{
	int planeIndex;

	for (planeIndex=0;planeIndex<numPlanes;planeIndex++)
	{
		if (planes[planeIndex])
		{
			fileInfoTable->iface->lpVtbl->Free(planes[planeIndex]);
			planes[planeIndex]=NULL;
		}
	}
}

static BOOL IMAGINEAPI saveFile(IMAGINEPLUGINFILEINFOTABLE *fileInfoTable,LPIMAGINEBITMAP dib,IMAGINESAVEPARAM *saveParam,int flags)
{
	BOOL result=FALSE;
	BYTE *image=NULL;
	BYTE *planes[8]={NULL};
	int numPlanes=0;
	SAVE_USER_DATA userData=
	{
		fileInfoTable,
		saveParam,
		flags,
	};

	__try
	{
		if (!setjmp(userData.jmpb))
		{
			const LONG bitCount=fileInfoTable->iface->lpVtbl->GetBitCount(dib);

			saveParam->caps|=IMAGINECAPS_GRAYSCALE;

			if (bitCount>8)
			{
				saveParam->errorCode=IMAGINEERROR_COLORNOTSUPPORTED;
			}
			else
			{
				PALETTEENTRY palette[256];

				if
				(
					(!fileInfoTable->iface->lpVtbl->GetPalette(dib,palette))
					||(!fileInfoTable->iface->lpVtbl->UtilCheckGrayscalePalette(palette,1<<bitCount))
				)
				{
					saveParam->errorCode=IMAGINEERROR_GRAYSCALEONLY;
				}
			}

			if (!saveParam->errorCode)
			{
				if (!(flags&IMAGINESAVEPARAM_TEST))
				{
					const LONG length=fileInfoTable->iface->lpVtbl->GetLength(dib);
					if (length)
					{
						saveParam->sb=fileInfoTable->iface->lpVtbl->sbAlloc(length,32768);
						if (saveParam->sb)
						{
							const LONG width=fileInfoTable->iface->lpVtbl->GetWidth(dib);
							const LONG height=fileInfoTable->iface->lpVtbl->GetHeight(dib);
							const LONG widthBytes=fileInfoTable->iface->lpVtbl->GetWidthBytes(dib);
							const LONG pureWidthBytes=fileInfoTable->iface->lpVtbl->GetPureWidthBytes(dib);
							const LONG bytesPerPlaneScanline=(width+7)/8;

							image=fileInfoTable->iface->lpVtbl->Alloc(pureWidthBytes*height);
							if (image)
							{
								int planeIndex;
								LONG y;

								numPlanes=bitCount;

								for (y=0;y<height;y++)
								{
									const BYTE *srcLine=fileInfoTable->iface->lpVtbl->GetLineBits(dib,y);
									BYTE *destLine=image+y*pureWidthBytes;

									memcpy(destLine,srcLine,pureWidthBytes);

									if (numPlanes<=1)
										invertScanline(destLine,pureWidthBytes);
								}

								for (planeIndex=0;(planeIndex<numPlanes)&&(!saveParam->errorCode);planeIndex++)
								{
									planes[planeIndex]=fileInfoTable->iface->lpVtbl->Alloc(bytesPerPlaneScanline*height);
									if (!planes[planeIndex])
										saveParam->errorCode=IMAGINEERROR_OUTOFMEMORY;
								}

								if (!saveParam->errorCode)
								{
									const int order=JBG_ILEAVE|JBG_SMID;
									const int options=JBG_TPDON|JBG_TPBON|JBG_DPON;
									unsigned long l0=-1;
									int mx=-1;

									userData.callbackParam.dib=dib;
									userData.callbackParam.param=saveParam->callback.param;
									userData.callbackParam.current=0;
									userData.callbackParam.overall=0;

									if (numPlanes<=1)
									{
										memcpy(planes[0],image,pureWidthBytes*height);
									}
									else
									{
										const int useGraycode=1;

										jbg_split_planes(width,height,numPlanes,numPlanes,image,planes,useGraycode);
									}

									if (image)
									{
										fileInfoTable->iface->lpVtbl->Free(image);
										image=NULL;
									}

									jbg_enc_init(&userData.jbig_state,width,height,numPlanes,planes,dataOutProc,&userData);
									jbg_enc_lrlmax(&userData.jbig_state,width,height);
									jbg_enc_lrange(&userData.jbig_state,-1,-1);

									jbg_enc_options(&userData.jbig_state,order,options,l0,mx,-1);
									jbg_enc_out(&userData.jbig_state);

									result=TRUE;
								}
							}
							else
							{
								saveParam->errorCode=IMAGINEERROR_OUTOFMEMORY;
							}
						}
						else
						{
							saveParam->errorCode=IMAGINEERROR_OUTOFMEMORY;
						}
					}
				}
				else
				{
					result=TRUE;
				}
			}
		}
	}
	__except (EXCEPTION_EXECUTE_HANDLER)
	{
		saveParam->errorCode=IMAGINEERROR_INVALIDDATA;
	}

	freePlanes(fileInfoTable,numPlanes,planes);

	if (image)
	{
		fileInfoTable->iface->lpVtbl->Free(image);
		image=NULL;
	}

	if (userData.jbig_state.s)
		jbg_enc_free(&userData.jbig_state);

	return result;
}

static const IMAGINEFILEINFOITEM fileInfoItemA=
{
	checkFile,
	loadFile,
	saveFile,
	DIBFILETYPE_JBIG,
	DIBEXTENSION_JBIG,
};

static const IMAGINEFILEINFOITEM fileInfoItemW=
{
	checkFile,
	loadFile,
	saveFile,
	(LPCTSTR)UNICODE_TEXT(DIBFILETYPE_JBIG),
	(LPCTSTR)UNICODE_TEXT(DIBEXTENSION_JBIG),
};

const IMAGINEFILEINFOITEM *IMAGINEAPI JBIGGetFileInfoA(void)
{
	return &fileInfoItemA;
}

const IMAGINEFILEINFOITEM *IMAGINEAPI JBIGGetFileInfoW(void)
{
	return &fileInfoItemW;
}
