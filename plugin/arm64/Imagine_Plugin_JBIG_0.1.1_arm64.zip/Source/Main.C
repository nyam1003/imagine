#include "Main.H"

static BOOL IMAGINEAPI registerProcA(const IMAGINEPLUGININTERFACE *iface)
{
	return (BOOL)iface->lpVtbl->RegisterFileType(JBIGGetFileInfoA());
}

static BOOL IMAGINEAPI registerProcW(const IMAGINEPLUGININTERFACE *iface)
{
	return (BOOL)iface->lpVtbl->RegisterFileType(JBIGGetFileInfoW());
}

static BOOL IMAGINEAPI infoProcA(const IMAGINEPLUGININTERFACE *iface,HINSTANCE hInstance,HWND parent)
{
	return InfoDialog(iface,hInstance,parent);
}

static BOOL IMAGINEAPI infoProcW(const IMAGINEPLUGININTERFACE *iface,HINSTANCE hInstance,HWND parent)
{
	return InfoDialog(iface,hInstance,parent);
}

static const IMAGINEPLUGININFOA pluginInfoA=
{
	sizeof(pluginInfoA),
	registerProcA,
	VERSION_NUMBER,
	INSTANCE_NAME,
	MAKE_IMAGINEPLUGININTERFACE_VERSION(1,5,3,0),
	NULL,
	infoProcA,
};

static const IMAGINEPLUGININFOW pluginInfoW=
{
	sizeof(pluginInfoW),
	registerProcW,
	VERSION_NUMBER,
	UNICODE_TEXT(INSTANCE_NAME),
	MAKE_IMAGINEPLUGININTERFACE_VERSION(1,5,3,0),
	NULL,
	infoProcW,
};

BOOL CALLBACK DllMain(HINSTANCE hInstance,DWORD dwReason,LPVOID lpvReserved)
{
	return TRUE;
}

BOOL IMAGINEAPI ImaginePluginGetInfoA(IMAGINEPLUGININFOA *dest)
{
	*dest=pluginInfoA;

	return TRUE;
}

BOOL IMAGINEAPI ImaginePluginGetInfoW(IMAGINEPLUGININFOW *dest)
{
	*dest=pluginInfoW;

	return TRUE;
}
