#define STRICT
#define WIN32_LEAN_AND_MEAN

#include <string.h>
#include <windows.h>
#include "ImagPlug.H"
#include "IPS.H"

static BOOL IMAGINEAPI ImaginePluginRegisterA(LPCIMAGINEPLUGININTERFACE iface);
static BOOL IMAGINEAPI ImaginePluginRegisterW(LPCIMAGINEPLUGININTERFACE iface);

static const IMAGINEPLUGININFO infoA=
{
	sizeof(infoA),
	ImaginePluginRegisterA,
	(LPVOID)(IMAGINEPLUGININTERFACE_VERSION),
	(LPVOID)("Imagine Plugin Sample File Plugin"),
};

static const IMAGINEPLUGININFO infoW=
{
	sizeof(infoW),
	ImaginePluginRegisterW,
	TEXT(IMAGINEPLUGININTERFACE_VERSION),
	TEXT("Imagine Plugin Sample File Plugin"),
};

BOOL CALLBACK DllMain(HINSTANCE hInstance,DWORD dwReason,LPVOID lpvReserved)
{
	BOOL result;

	result=TRUE;

	return result;
}

BOOL IMAGINEAPI ImaginePluginGetInfoA(LPIMAGINEPLUGININFO dest)
{
	BOOL result;

	result=FALSE;

	if (dest!=NULL)
	{
		memcpy(dest,&infoA,sizeof(*dest));
		result=TRUE;
	}

	return result;
}

BOOL IMAGINEAPI ImaginePluginGetInfoW(LPIMAGINEPLUGININFO dest)
{
	BOOL result;

	result=FALSE;

	if (dest!=NULL)
	{
		memcpy(dest,&infoW,sizeof(*dest));
		result=TRUE;
	}

	return result;
}

static BOOL IMAGINEAPI ImaginePluginRegisterA(LPCIMAGINEPLUGININTERFACE iface)
{
	LPCIMAGINEFILEINFOITEM ifii;
	BOOL result;

	result=FALSE;

	ifii=IPSGetFileInfoA();
	if (ifii!=NULL)
	{
		if (iface->lpVtbl->RegisterFileType(ifii)!=NULL)
			result=TRUE;
	}

	return result;
}

static BOOL IMAGINEAPI ImaginePluginRegisterW(LPCIMAGINEPLUGININTERFACE iface)
{
	LPCIMAGINEFILEINFOITEM ifii;
	BOOL result;

	result=FALSE;

	ifii=IPSGetFileInfoW();
	if (ifii!=NULL)
	{
		if (iface->lpVtbl->RegisterFileType(ifii)!=NULL)
			result=TRUE;
	}

	return result;
}
