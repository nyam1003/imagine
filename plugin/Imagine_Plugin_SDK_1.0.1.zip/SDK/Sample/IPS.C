#define STRICT
#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include "ImagPlug.H"
#include "IPS.H"

static BOOL IMAGINEAPI checkFile(LPIMAGINEPLUGINFILEINFOTABLE fileInfoTable,LPIMAGINELOADPARAM loadParam,int flags);
static LPIMAGINEBITMAP IMAGINEAPI loadFile(LPIMAGINEPLUGINFILEINFOTABLE fileInfoTable,LPIMAGINELOADPARAM loadParam,int flags);
static BOOL IMAGINEAPI saveFile(LPIMAGINEPLUGINFILEINFOTABLE fileInfoTable,LPIMAGINEBITMAP bitmap,LPIMAGINESAVEPARAM saveParam,int flags);

static void importPalette(LPPALETTEENTRY palette,LPIPSPALETTEENTRY entry,int entryCount);
static void exportPalette(LPPALETTEENTRY palette,LPIPSPALETTEENTRY entry,int entryCount);

// file information (ANSI version)
static const IMAGINEFILEINFOITEM ifiA=
{
	(LPVOID)checkFile, // Check procedure
	(LPVOID)loadFile, // Load buffer procedure
	(LPVOID)saveFile, // Save buffer procedure
	(LPVOID)("Imagine Plugin Sample"), // Image file description
	(LPVOID)("IPS;IPSF"), // Image file extension
};

// file information (UNICODE version)
static const IMAGINEFILEINFOITEM ifiW=
{
	(LPVOID)checkFile, // Check procedure
	(LPVOID)loadFile, // Load buffer procedure
	(LPVOID)saveFile, // Save buffer procedure
	(LPVOID)(L"Imagine Plugin Sample"), // Image file description
	(LPVOID)(L"IPS;IPSF"), // Image file extension
};

LPCIMAGINEFILEINFOITEM IMAGINEAPI IPSGetFileInfoA(void)
{
	return &ifiA;
}

LPCIMAGINEFILEINFOITEM IMAGINEAPI IPSGetFileInfoW(void)
{
	return &ifiW;
}

static BOOL IMAGINEAPI checkFile(LPIMAGINEPLUGINFILEINFOTABLE fileInfoTable,LPIMAGINELOADPARAM loadParam,int flags)
{
	LPIPSHEADER header;
	BOOL isValid;

	isValid=FALSE;

	header=(LPIPSHEADER)loadParam->lpData;

	if (header->dwSignature==IPS_SIGNATURE)
		isValid=TRUE;

	return isValid;
}

static LPIMAGINEBITMAP IMAGINEAPI loadFile(LPIMAGINEPLUGINFILEINFOTABLE fileInfoTable,LPIMAGINELOADPARAM loadParam,int flags)
{
	LPCIMAGINEPLUGININTERFACE iface;
	LPIPSHEADER header;
	LPIMAGINEBITMAP bitmap;
	LONG width,height;
	LONG bitCount;
	PALETTEENTRY palette[256];
	LPIPSPALETTEENTRY entry;
	LPBYTE lpData;
	LPBYTE lpBits;
	LONG widthBytes;
	LONG pureWidthBytes;
	IMAGINECALLBACKPARAM callback;
	int y;

	bitmap=NULL;

	iface=fileInfoTable->iface;
	if (iface!=NULL)
	{
		header=(LPIPSHEADER)loadParam->lpData;

		width=(LONG)header->dwWidth;
		height=(LONG)header->dwHeight;
		bitCount=(LONG)header->dwBitCount;

		bitmap=iface->lpVtbl->Create(width,height,bitCount,flags);
		if (bitmap!=NULL)
		{
			if (!(flags&IMAGINELOADPARAM_GETINFO))
			{
				lpData=(LPBYTE)(header+1);

				if (bitCount<=8)
				{
					entry=(LPIPSPALETTEENTRY)lpData;
					importPalette(palette,entry,1<<bitCount);
					iface->lpVtbl->SetPalette(bitmap,palette);
					lpData=(LPBYTE)(entry+(1<<bitCount));
				}

				pureWidthBytes=(width*bitCount)/8;
				widthBytes=iface->lpVtbl->GetWidthBytes(bitmap);

				lpBits=iface->lpVtbl->GetBits(bitmap);
				lpBits+=iface->lpVtbl->GetLength(bitmap)-widthBytes;

				callback.dib=bitmap;
				callback.param=loadParam->callback.param;
				callback.current=0;
				callback.overall=height-1;

				for (y=height;y>0;y--)
				{
					memcpy(lpBits,lpData,pureWidthBytes);

					if (flags&IMAGINELOADPARAM_CALLBACK)
					{
						if (!loadParam->callback.proc(&callback))
						{
							loadParam->errorCode=IMAGINEERROR_ABORTED;
							break;
						}
					}

					lpData+=pureWidthBytes;
					lpBits-=widthBytes;
					callback.current++;
				}
			}
		}
		else
		{
			loadParam->errorCode=IMAGINEERROR_OUTOFMEMORY;
		}
	}

	return bitmap;
}

static BOOL IMAGINEAPI saveFile(LPIMAGINEPLUGINFILEINFOTABLE fileInfoTable,LPIMAGINEBITMAP bitmap,LPIMAGINESAVEPARAM saveParam,int flags)
{
	LPCIMAGINEPLUGININTERFACE iface;
	IPSHEADER header;
	LPIMAGINESMARTBUFFER sb;
	LONG width,height;
	LONG bitCount;
	IMAGINECALLBACKPARAM callback;
	LONG pureWidthBytes;
	LONG widthBytes;
	LPBYTE lpData;
	PALETTEENTRY palette[256];
	IPSPALETTEENTRY entry[256];
	int length;
	int y;
	BOOL result;

	result=FALSE;

	iface=fileInfoTable->iface;
	if (iface!=NULL)
	{
		bitCount=iface->lpVtbl->GetBitCount(bitmap);
		switch (bitCount)
		{
		case 8:
		case 24:
			// Assume that only 8bit and 24bit colors are supported.
			break;

		default:
			saveParam->errorCode=IMAGINEERROR_COLORNOTSUPPORTED;
			break;
		}

		if (saveParam->errorCode!=IMAGINEERROR_COLORNOTSUPPORTED)
		{
			if (!(flags&IMAGINESAVEPARAM_TEST)) // The rest can be saved with no problems.
			{
				length=iface->lpVtbl->GetLength(bitmap);
				if (length>0)
				{
					// First argument: The size of initial allocation
					// Second argument: The size of allcation unit (When the initial allocated memory is not enough)
					// They can be any values, but they affect to performance. (Reallocation)
					sb=iface->lpVtbl->sbAlloc(length,32768);
					if (sb!=NULL)
					{
						saveParam->sb=sb;

						width=iface->lpVtbl->GetWidth(bitmap);
						height=iface->lpVtbl->GetHeight(bitmap);

						header.dwSignature=IPS_SIGNATURE;
						header.dwWidth=(DWORD)width;
						header.dwHeight=(DWORD)height;
						header.dwBitCount=(DWORD)bitCount;

						if (iface->lpVtbl->sbWrite(sb,sb->current,&header,sizeof(header))!=NULL)
						{
							if (bitCount<=8)
							{
								iface->lpVtbl->GetPalette(bitmap,palette);
								exportPalette(palette,entry,1<<bitCount);

								if (iface->lpVtbl->sbWrite(sb,sb->current,entry,sizeof(*entry)*(1<<bitCount))==NULL)
									saveParam->errorCode=IMAGINEERROR_WRITEERROR;
							}

							if (saveParam->errorCode==IMAGINEERROR_NOERROR)
							{
								callback.dib=bitmap;
								callback.param=saveParam->callback.param;
								callback.current=0;
								callback.overall=height-1;

								pureWidthBytes=iface->lpVtbl->GetPureWidthBytes(bitmap);
								if (pureWidthBytes>0)
								{
									widthBytes=iface->lpVtbl->GetWidthBytes(bitmap);
									lpData=iface->lpVtbl->GetBits(bitmap);
									lpData+=length-widthBytes;

									for (y=height;y>0;y--)
									{
										if (iface->lpVtbl->sbWrite(sb,sb->current,lpData,pureWidthBytes)==NULL)
										{
											saveParam->errorCode=IMAGINEERROR_WRITEERROR;
											break;
										}

										if (flags&IMAGINESAVEPARAM_CALLBACK)
										{
											if (!saveParam->callback.proc(&callback))
											{
												saveParam->errorCode=IMAGINEERROR_ABORTED;
												break;
											}
										}

										lpData-=widthBytes;
										callback.current++;
									}
								}
							}
						}
						else
						{
							saveParam->errorCode=IMAGINEERROR_WRITEERROR;
						}
					}
					else
					{
						saveParam->errorCode=IMAGINEERROR_OUTOFMEMORY;
					}
				}
			}

			if (saveParam->errorCode==IMAGINEERROR_NOERROR)
				result=TRUE;
		}
	}

	return result;
}

static void importPalette(LPPALETTEENTRY palette,LPIPSPALETTEENTRY entry,int entryCount)
{
	int i;

	for (i=entryCount;i>0;i--)
	{
		palette->peRed=entry->bRed;
		palette->peGreen=entry->bGreen;
		palette->peBlue=entry->bBlue;
		palette->peFlags=0;

		palette++;
		entry++;
	}

	return;
}

static void exportPalette(LPPALETTEENTRY palette,LPIPSPALETTEENTRY entry,int entryCount)
{
	int i;

	for (i=entryCount;i>0;i--)
	{
		entry->bRed=palette->peRed;
		entry->bGreen=palette->peGreen;
		entry->bBlue=palette->peBlue;
		entry->bReserved=0;

		palette++;
		entry++;
	}

	return;
}
