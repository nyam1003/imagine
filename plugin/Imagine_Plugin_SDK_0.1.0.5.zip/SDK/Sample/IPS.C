#define STRICT
#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include "ImagPlug.H"
#include "IPS.H"

static BOOL IMAGINEAPI IPSCheck(LPIMAGINEFILEINFO table,LPIMAGINELOADPARAM param,int nFlags);
static LPIMAGINEBITMAP IMAGINEAPI IPSLoad(LPIMAGINEFILEINFO table,LPIMAGINELOADPARAM param,int nFlags);
static BOOL IMAGINEAPI IPSSave(LPIMAGINEFILEINFO table,LPIMAGINEBITMAP bitmap,LPIMAGINESAVEPARAM param,int nFlags);

static BOOL IPSImportPalette(LPPALETTEENTRY palette,LPIPSPALETTEENTRY entry,int nEntries);
static BOOL IPSExportPalette(LPPALETTEENTRY palette,LPIPSPALETTEENTRY entry,int nEntries);

static const IMAGINEFILEINFO ifiA=
{
	(LPVOID)IPSCheck, // Check procedure
	(LPVOID)IPSLoad, // Load buffer procedure
	(LPVOID)IPSSave, // Save buffer procedure
	(LPVOID)("Imagine Plugin Sample"), // Image file description
	(LPVOID)("IPS;IPSF"), // Image file extension
};

static const IMAGINEFILEINFO ifiW=
{
	(LPVOID)IPSCheck, // Check procedure
	(LPVOID)IPSLoad, // Load buffer procedure
	(LPVOID)IPSSave, // Save buffer procedure
	TEXT("Imagine Plugin Sample"), // Image file description
	TEXT("IPS;IPSF"), // Image file extension
};

LPCIMAGINEFILEINFO IMAGINEAPI IPSGetFileInfoA(void)
{
	return &ifiA;
}

LPCIMAGINEFILEINFO IMAGINEAPI IPSGetFileInfoW(void)
{
	return &ifiW;
}

static BOOL IMAGINEAPI IPSCheck(LPIMAGINEFILEINFO table,LPIMAGINELOADPARAM param,int nFlags)
{
	LPIPSHEADER header;

	header=(LPIPSHEADER)param->lpData;

	if (header->dwSignature!=IPS_SIGNATURE)
		return FALSE;

	return TRUE;
}

static LPIMAGINEBITMAP IMAGINEAPI IPSLoad(LPIMAGINEFILEINFO table,LPIMAGINELOADPARAM param,int nFlags)
{
	LPCIMAGINEPLUGININTERFACE iface;
	LPIPSHEADER header;
	LPIMAGINEBITMAP bitmap;
	LONG nWidth,nHeight;
	LONG nBitCount;
	PALETTEENTRY palette[256];
	LPIPSPALETTEENTRY entry;
	LPBYTE lpData;
	LPBYTE lpBits;
	LONG nWidthBytes;
	LONG bytesperscanline;
	IMAGINECALLBACKPARAM callback;
	int y;

	iface=table->iface;
	if (iface==NULL)
		return NULL;

	header=(LPIPSHEADER)param->lpData;

	nWidth=(LONG)header->dwWidth;
	nHeight=(LONG)header->dwHeight;
	nBitCount=(LONG)header->dwBitCount;

	bitmap=iface->lpVtbl->Create(nWidth,nHeight,nBitCount,nFlags);
	if (bitmap==NULL)
	{
		param->dwErrorCode=IMAGINEERROR_OUTOFMEMORY;
		return NULL;
	}

	if (nFlags&IMAGINELOADPARAM_GETINFO)
		return bitmap;

	lpData=(LPBYTE)(header+1);

	if (nBitCount<=8)
	{
		entry=(LPIPSPALETTEENTRY)lpData;
		IPSImportPalette(palette,entry,1<<nBitCount);
		iface->lpVtbl->SetPalette(bitmap,palette);
		lpData=(LPBYTE)(entry+(1<<nBitCount));
	}

	bytesperscanline=(nWidth*nBitCount)/8;
	nWidthBytes=iface->lpVtbl->GetWidthBytes(bitmap);

	lpBits=iface->lpVtbl->GetBits(bitmap);
	lpBits+=iface->lpVtbl->GetLength(bitmap)-nWidthBytes;

	callback.dib=bitmap;
	callback.param=param->callback.param;
	callback.current=1;
	callback.overall=nHeight;

	for (y=nHeight;y>0;y--,lpData+=bytesperscanline,lpBits-=nWidthBytes,callback.current++)
	{
		memcpy(lpBits,lpData,bytesperscanline);

		if (!(nFlags&IMAGINELOADPARAM_CALLBACK))
			continue;

		if (!param->callback.proc(&callback))
		{
			param->dwErrorCode=IMAGINEERROR_ABORTED;
			return bitmap;
		}
	}

	return bitmap;
}

static BOOL IMAGINEAPI IPSSave(LPIMAGINEFILEINFO table,LPIMAGINEBITMAP bitmap,LPIMAGINESAVEPARAM param,int nFlags)
{
	LPCIMAGINEPLUGININTERFACE iface;
	IPSHEADER header;
	LPIMAGINESMARTBUFFER sb;
	LONG nWidth,nHeight;
	LONG nBitCount;
	IMAGINECALLBACKPARAM callback;
	LONG bytesperscanline;
	LONG nWidthBytes;
	LPBYTE lpData;
	PALETTEENTRY palette[256];
	IPSPALETTEENTRY entry[256];
	int length;
	int y;

	iface=table->iface;
	if (iface==NULL)
		return FALSE;

	nBitCount=iface->lpVtbl->GetBitCount(bitmap);

	switch (nBitCount)
	{
	case 8:
	case 24:
		// Assume that only 8bit and 24bit colors are supported.
		break;

	default:
		param->dwErrorCode=IMAGINEERROR_COLORNOTSUPPORTED;
		return FALSE;
	}

	if (nFlags&IMAGINESAVEPARAM_TEST) // The rest can be saved with no problems.
		return TRUE;

	length=iface->lpVtbl->GetLength(bitmap);

	// First argument: The size of initial allocation
	// Second argument: The size of allcation unit (When the initial allocated memory is not enough)
	// They can be any values, but they affect to performance. (Reallocation)
	sb=iface->lpVtbl->sbAlloc(length,32768);
	if (sb==NULL)
	{
		param->dwErrorCode=IMAGINEERROR_OUTOFMEMORY;
		return FALSE;
	}
	param->sb=sb;

	nWidth=iface->lpVtbl->GetWidth(bitmap);
	nHeight=iface->lpVtbl->GetHeight(bitmap);

	header.dwSignature=IPS_SIGNATURE;
	header.dwWidth=(DWORD)nWidth;
	header.dwHeight=(DWORD)nHeight;
	header.dwBitCount=(DWORD)nBitCount;

	if (iface->lpVtbl->sbWrite(sb,sb->current,&header,sizeof(header))==NULL)
	{
		param->dwErrorCode=IMAGINEERROR_WRITEERROR;
		return FALSE;
	}

	if (nBitCount<=8)
	{
		iface->lpVtbl->GetPalette(bitmap,palette);
		IPSExportPalette(palette,entry,1<<nBitCount);

		if (iface->lpVtbl->sbWrite(sb,sb->current,entry,sizeof(*entry)*(1<<nBitCount))==NULL)
		{
			param->dwErrorCode=IMAGINEERROR_WRITEERROR;
			return FALSE;
		}
	}

	callback.dib=bitmap;
	callback.param=param->callback.param;
	callback.current=1;
	callback.overall=nHeight;

	bytesperscanline=iface->lpVtbl->GetPureWidthBytes(bitmap);

	nWidthBytes=iface->lpVtbl->GetWidthBytes(bitmap);
	lpData=iface->lpVtbl->GetBits(bitmap);
	lpData+=length-nWidthBytes;

	for (y=nHeight;y>0;y--,lpData-=nWidthBytes,callback.current++)
	{
		if (iface->lpVtbl->sbWrite(sb,sb->current,lpData,bytesperscanline)==NULL)
		{
			param->dwErrorCode=IMAGINEERROR_WRITEERROR;
			return FALSE;
		}

		if (!(nFlags&IMAGINESAVEPARAM_CALLBACK))
			continue;

		if (!param->callback.proc(&callback))
		{
			param->dwErrorCode=IMAGINEERROR_ABORTED;
			return FALSE;
		}
	}

	return TRUE;
}

static BOOL IPSImportPalette(LPPALETTEENTRY palette,LPIPSPALETTEENTRY entry,int nEntries)
{
	int i;

	for (i=nEntries;i>0;i--,palette++,entry++)
	{
		palette->peRed=entry->bRed;
		palette->peGreen=entry->bGreen;
		palette->peBlue=entry->bBlue;
		palette->peFlags=0;
	}

	return TRUE;
}

static BOOL IPSExportPalette(LPPALETTEENTRY palette,LPIPSPALETTEENTRY entry,int nEntries)
{
	int i;

	for (i=nEntries;i>0;i--,palette++,entry++)
	{
		entry->bRed=palette->peRed;
		entry->bGreen=palette->peGreen;
		entry->bBlue=palette->peBlue;
		entry->bReserved=0;
	}

	return TRUE;
}
