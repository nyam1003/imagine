#include "Main.H"

static BOOL IMAGINEAPI registerProcA(const IMAGINEPLUGININTERFACE *iface)
{
	return (BOOL)iface->lpVtbl->RegisterFileType(JBIGGetFileInfoA());
}

static BOOL IMAGINEAPI registerProcW(const IMAGINEPLUGININTERFACE *iface)
{
	return (BOOL)iface->lpVtbl->RegisterFileType(JBIGGetFileInfoW());
}

static const IMAGINEPLUGININFOA pluginInfoA=
{
	sizeof(pluginInfoA),
	registerProcA,
	VERSION_NUMBER,
	INSTANCE_NAME,
	IMAGINEPLUGININTERFACE_VERSION,
};

static const IMAGINEPLUGININFOW pluginInfoW=
{
	sizeof(pluginInfoW),
	registerProcW,
	VERSION_NUMBER,
	UNICODE_TEXT(INSTANCE_NAME),
	IMAGINEPLUGININTERFACE_VERSION,
};

BOOL CALLBACK DllMain(HINSTANCE hInstance,DWORD dwReason,LPVOID lpvReserved)
{
	BOOL result=TRUE;

	return result;
}

BOOL IMAGINEAPI ImaginePluginGetInfoA(IMAGINEPLUGININFOA *dest)
{
	BOOL result=TRUE;

	*dest=pluginInfoA;

	return result;
}

BOOL IMAGINEAPI ImaginePluginGetInfoW(IMAGINEPLUGININFOW *dest)
{
	BOOL result=TRUE;

	*dest=pluginInfoW;

	return result;
}
