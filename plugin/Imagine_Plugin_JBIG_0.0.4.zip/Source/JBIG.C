#include "Main.H"

typedef struct DATA_OUT_PROC_PARAM
{
	const IMAGINEPLUGININTERFACE *iface;
	IMAGINESAVEPARAM *saveParam;
} DATA_OUT_PROC_PARAM;

static void invertScanline(LPBYTE buffer,int bufferLength)
{
	int i;

	for (i=bufferLength/sizeof(DWORD);i>0;i--,buffer+=sizeof(DWORD))
		*((LPDWORD)buffer)^=0xFFFFFFFF;

	for (i=bufferLength%sizeof(DWORD);i>0;i--,buffer+=sizeof(BYTE))
		*((LPBYTE)buffer)^=0xFF;
}

static void dataOutProc(unsigned char *start,size_t len,void *file)
{
	DATA_OUT_PROC_PARAM *dataOutProcParam=(DATA_OUT_PROC_PARAM *)file;
	const IMAGINEPLUGININTERFACE *iface=dataOutProcParam->iface;
	IMAGINESAVEPARAM *saveParam=dataOutProcParam->saveParam;

	if (iface->lpVtbl->sbWrite(saveParam->sb,saveParam->sb->current,start,len)!=NULL)
	{

	}
	else
	{
		saveParam->errorCode=IMAGINEERROR_WRITEERROR;
	}
}

static BOOL IMAGINEAPI checkFile(IMAGINEPLUGINFILEINFOTABLE *fileInfoTable,IMAGINELOADPARAM *loadParam,int flags)
{
	BOOL isValid=FALSE;

	if (flags&IMAGINELOADPARAM_DETECTEXTENSION)
		isValid=TRUE;

	return isValid;
}

static LPIMAGINEBITMAP IMAGINEAPI loadFile(IMAGINEPLUGINFILEINFOTABLE *fileInfoTable,IMAGINELOADPARAM *loadParam,int flags)
{
	LPIMAGINEBITMAP first=NULL;
	struct jbg_dec_state jbig_state={0};
	BOOL jbigDecoderInitialized=FALSE;

	__try
	{
		if (!(flags&IMAGINELOADPARAM_GETINFO))
		{
			const IMAGINEPLUGININTERFACE *iface=fileInfoTable->iface;
			if (iface!=NULL)
			{
				BOOL decodeAtOnce=FALSE;

				jbg_dec_init(&jbig_state);
				jbigDecoderInitialized=TRUE;

				if (decodeAtOnce)
				{
					jbg_dec_in(&jbig_state,(LPBYTE)loadParam->buffer,loadParam->length,NULL);
				}
				else
				{
					BOOL keepGoing=TRUE;
					int status=JBG_EAGAIN;
					BYTE *pBuffer=loadParam->buffer;
					int bufferLength=0;

					while (keepGoing)
					{
						bufferLength=4096;
						if (pBuffer+bufferLength>(BYTE *)loadParam->buffer+loadParam->length)
							bufferLength-=(pBuffer+bufferLength)-((BYTE *)loadParam->buffer+loadParam->length);

						if (bufferLength>0)
						{
							BYTE *p=pBuffer;
							int remainedBufferLength=bufferLength;

							while ((remainedBufferLength>0)&&((status==JBG_EAGAIN)||(status==JBG_EOK)))
							{
								size_t count=0;

								status=jbg_dec_in(&jbig_state,p,remainedBufferLength,&count);
								p+=count;
								remainedBufferLength-=(int)count;
							}

							if ((status!=JBG_EAGAIN)&&(status!=JBG_EOK))
								keepGoing=FALSE;

							pBuffer+=bufferLength;
						}
						else
						{
							keepGoing=FALSE;
						}
					}
				}

				if (jbigDecoderInitialized)
				{
					LONG width=jbg_dec_getwidth(&jbig_state);
					LONG height=jbg_dec_getheight(&jbig_state);
					LONG planeCount=jbg_dec_getplanes(&jbig_state);
					LONG bitCount=planeCount;
					LPIMAGINEBITMAP bitmap=iface->lpVtbl->Create(width,height,bitCount,flags);
					if (bitmap!=NULL)
					{
						LONG bytesPerPlaneScanline=(width+7)/8;
						LONG widthBytes=iface->lpVtbl->GetWidthBytes(bitmap);
						LONG pureWidthBytes=iface->lpVtbl->GetPureWidthBytes(bitmap);
						PALETTEENTRY palette[256];
						int planeIndex=0;

						if (first==NULL)
							first=bitmap;

						iface->lpVtbl->SetCompression(bitmap,IMAGINECOMPRESSION_JBIG);

						if (iface->lpVtbl->UtilCreateGrayscalePalette(palette,1<<bitCount))
							iface->lpVtbl->SetPalette(bitmap,palette);

						for (planeIndex=0;planeIndex<planeCount;planeIndex++)
						{
							unsigned char *plane=jbg_dec_getimage(&jbig_state,planeIndex);
							unsigned char *scanline=plane;
							int y=0;

							for (y=0;y<height;y++)
							{
								LPBYTE line=iface->lpVtbl->GetLineBits(bitmap,y);

								if (planeCount<=1) // 1-bit B/W
								{
									memcpy(line,scanline,bytesPerPlaneScanline);
									invertScanline(line,bytesPerPlaneScanline);
								}
								else // 8-bit grayscale
								{
									int x=0;

									if (planeIndex==0)
										memset(line,0,pureWidthBytes);

									for (x=0;x<width;x++)
									{
										LPBYTE pScanline=scanline+(x/8);
										LPBYTE pLine=line+((x*planeCount)/8);
										BYTE scanlineData=(*pScanline>>(7-x%8))&1;
										BYTE lineData=*pLine;

										*pLine=(lineData<<1)|(scanlineData^(1&lineData));
									}
								}

								scanline+=bytesPerPlaneScanline;
							}
						}
					}
					else
					{
						loadParam->errorCode=IMAGINEERROR_OUTOFMEMORY;
					}
				}
			}
		}
		else
		{
			loadParam->errorCode=IMAGINEERROR_GETINFONOTSUPPORTED;
		}
	}
	__except (EXCEPTION_EXECUTE_HANDLER)
	{
		loadParam->errorCode=IMAGINEERROR_INVALIDDATA;
	}

	if (jbigDecoderInitialized)
		jbg_dec_free(&jbig_state);

	return first;
}

static BOOL IMAGINEAPI saveFile(IMAGINEPLUGINFILEINFOTABLE *fileInfoTable,LPIMAGINEBITMAP bitmap,IMAGINESAVEPARAM *saveParam,int flags)
{
	BOOL result=FALSE;
	BOOL jbigEncoderInitialized=FALSE;
	unsigned char *image=NULL;
	unsigned char **planes=NULL;
	const IMAGINEPLUGININTERFACE *iface=fileInfoTable->iface;
	struct jbg_enc_state jbig_state={0};
	int planeCount=0;

	__try
	{
		LONG bitCount=iface->lpVtbl->GetBitCount(bitmap);

		if (bitCount<=8)
		{
			PALETTEENTRY palette[256]={0};

			if ((iface->lpVtbl->GetPalette(bitmap,palette)!=0)&&(iface->lpVtbl->UtilCheckGrayscalePalette(palette,1<<bitCount)))
			{
				if (flags&IMAGINESAVEPARAM_TEST)
				{
					result=TRUE;
				}
				else
				{
					LONG length=iface->lpVtbl->GetLength(bitmap);
					if (length!=0)
					{
						saveParam->sb=iface->lpVtbl->sbAlloc(length,32768);
						if (saveParam->sb!=NULL)
						{
							LONG width=iface->lpVtbl->GetWidth(bitmap);
							LONG height=iface->lpVtbl->GetHeight(bitmap);
							LONG widthBytes=iface->lpVtbl->GetWidthBytes(bitmap);
							LONG pureWidthBytes=iface->lpVtbl->GetPureWidthBytes(bitmap);
							LONG bytesPerPlaneScanline=(width+7)/8;

							image=iface->lpVtbl->Alloc(pureWidthBytes*height);
							if (image!=NULL)
							{
								LONG y=0;

								planeCount=bitCount;

								for (y=0;y<height;y++)
								{
									LPBYTE imageScanline=image+y*pureWidthBytes;

									memcpy(imageScanline,iface->lpVtbl->GetLineBits(bitmap,y),pureWidthBytes);

									if (planeCount<=1)
										invertScanline(imageScanline,pureWidthBytes);
								}

								planes=iface->lpVtbl->Alloc(sizeof(*planes)*planeCount);
								if (planes!=NULL)
								{
									int planeIndex=0;

									BOOL allocErrorOccured=FALSE;

									memset(planes,0,sizeof(*planes)*planeCount);

									for (planeIndex=0;(planeIndex<planeCount)&&(!allocErrorOccured);planeIndex++)
									{
										planes[planeIndex]=iface->lpVtbl->Alloc(bytesPerPlaneScanline*height);
										if (planes[planeIndex]==NULL)
											allocErrorOccured=TRUE;
									}

									if (!allocErrorOccured)
									{
										DATA_OUT_PROC_PARAM dataOutProcParam={iface,saveParam};
										int order=JBG_ILEAVE|JBG_SMID;
										int options=JBG_TPDON|JBG_TPBON|JBG_DPON;
										unsigned long l0=-1;
										int mx=-1;

										if (planeCount<=1)
										{
											memcpy(planes[0],image,pureWidthBytes*height);
										}
										else
										{
											int useGraycode=1;

											jbg_split_planes(width,height,planeCount,planeCount,image,planes,useGraycode);
										}

										if (image!=NULL)
										{
											iface->lpVtbl->Free(image);
											image=NULL;
										}

										jbg_enc_init(&jbig_state,width,height,planeCount,planes,dataOutProc,&dataOutProcParam);
										jbg_enc_lrlmax(&jbig_state,width,height);
										jbg_enc_lrange(&jbig_state,-1,-1);

										jbg_enc_options(&jbig_state,order,options,l0,mx,-1);
										jbg_enc_out(&jbig_state);

										result=TRUE;
									}
									else
									{
										saveParam->errorCode=IMAGINEERROR_OUTOFMEMORY;
									}
								}
								else
								{
									saveParam->errorCode=IMAGINEERROR_OUTOFMEMORY;
								}
							}
							else
							{
								saveParam->errorCode=IMAGINEERROR_OUTOFMEMORY;
							}
						}
						else
						{
							saveParam->errorCode=IMAGINEERROR_OUTOFMEMORY;
						}
					}
				}
			}
			else
			{
				saveParam->errorCode=IMAGINEERROR_GRAYSCALEONLY;
			}
		}
		else
		{
			saveParam->errorCode=IMAGINEERROR_COLORNOTSUPPORTED;
		}
	}
	__except (EXCEPTION_EXECUTE_HANDLER)
	{
		saveParam->errorCode=IMAGINEERROR_INVALIDDATA;
	}

	if (jbigEncoderInitialized)
		jbg_enc_free(&jbig_state);

	if (planes!=NULL)
	{
		int planeIndex=0;

		for (planeIndex=0;planeIndex<planeCount;planeIndex++)
		{
			if (planes[planeIndex]!=NULL)
			{
				iface->lpVtbl->Free(planes[planeIndex]);
				planes[planeIndex]=NULL;
			}
		}

		iface->lpVtbl->Free(planes);
		planes=NULL;
	}

	if (image!=NULL)
	{
		iface->lpVtbl->Free(image);
		image=NULL;
	}

	return result;
}

// file information (ANSI version)
static const IMAGINEFILEINFOITEM fileInfoItemA=
{
	checkFile,
	loadFile,
	NULL,
	FILETYPE_JBIG,
	EXTENSION_JBIG,
};

// file information (UNICODE version)
static const IMAGINEFILEINFOITEM fileInfoItemW=
{
	checkFile,
	loadFile,
	NULL,
	(LPCTSTR)UNICODE_TEXT(FILETYPE_JBIG),
	(LPCTSTR)UNICODE_TEXT(EXTENSION_JBIG),
};

const IMAGINEFILEINFOITEM *IMAGINEAPI JBIGGetFileInfoA(void)
{
	return &fileInfoItemA;
}

const IMAGINEFILEINFOITEM *IMAGINEAPI JBIGGetFileInfoW(void)
{
	return &fileInfoItemW;
}
